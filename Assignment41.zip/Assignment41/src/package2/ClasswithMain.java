package package2;

import java.io.IOException;
import java.util.Scanner;
import package1.SampleClass1;

public class ClasswithMain extends SampleClass1 
{
	public static void main(String... K) throws IOException 
	{
		Scanner objScanner = new Scanner(System.in);
		System.out.println("Please enter your name");
		String strInput = objScanner.nextLine();
		String printname = Printname(strInput);
		objScanner.close();
		System.out.println("Hello " + printname);
	}
}
