package package1;

public class SampleClass1 {

	protected static String Printname(String name)
	{
		return name;
	}
}
